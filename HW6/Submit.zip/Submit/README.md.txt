Do the slopes confirm our mathematical analysis of the algorithms?
	Yes
At what problem size does the n^(1.59) algorithm become faster than the other two algorithms
	The problem size with n^(1.59) becomes faster a little after an exponet of about size 10^3
